# plugin.video.mtelnow

To e Fork на първоначалната версия създена от ByJohnie <https://github.com/ByJohnie/plugin.video.mtelnow>

За автоматично инсталиране и обновяване може да използвате репозитори <https://lukavia.github.io/lukav-kodi-repo/>
